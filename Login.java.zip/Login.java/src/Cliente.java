public class Cliente {

    String nome;
    String telefone;
    String email;

    public Cliente(
            String nome,
            String telefone,
            String email
    ) {

        this.nome = nome;
        this.telefone = telefone;
        this.email = email;

    }

    public void mostrar() {

        System.out.println("\nCliente:");

        System.out.println("Nome: " + nome);

        System.out.println("Telefone: " + telefone);

        System.out.println("Email: " + email);

    }

}

