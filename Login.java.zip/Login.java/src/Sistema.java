    import java.util.ArrayList;

public class Sistema {

    ArrayList<Cliente> clientes =
            new ArrayList<>();

    public void cadastrar(
            Cliente cliente
    ) {

        clientes.add(cliente);

        System.out.println(
                "\nCliente cadastrado!"
        );

    }

    public void listar() {

        for (Cliente c : clientes) {

            c.mostrar();

        }

    }

}

