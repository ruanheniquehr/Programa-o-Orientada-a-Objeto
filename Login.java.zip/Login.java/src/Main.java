import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        Usuario usuario = null;

        int opcao;

        do {

            System.out.println("\n=== MENU ===");
            System.out.println("1 - Cadastrar Usuário");
            System.out.println("2 - Fazer Login");
            System.out.println("3 - Sair");

            System.out.print("Escolha: ");
            opcao = sc.nextInt();
            sc.nextLine();

            switch (opcao) {

                case 1:

                    System.out.println("\nCADASTRO");

                    System.out.print("Email: ");
                    String emailCadastro =
                            sc.nextLine();

                    System.out.print("Senha: ");
                    String senhaCadastro =
                            sc.nextLine();

                    usuario =
                            new Usuario(
                                    emailCadastro,
                                    senhaCadastro
                            );

                    System.out.println(
                            "Usuário cadastrado!"
                    );

                    break;

                case 2:

                    if (usuario == null) {

                        System.out.println(
                                "Cadastre primeiro!"
                        );

                        break;

                    }

                    System.out.println(
                            "\nLOGIN"
                    );

                    System.out.print(
                            "Email: "
                    );

                    String email =
                            sc.nextLine();

                    System.out.print(
                            "Senha: "
                    );

                    String senha =
                            sc.nextLine();

                    if (
                            usuario.login(
                                    email,
                                    senha
                            )
                    ) {

                        System.out.println(
                                "\nLogin realizado!"
                        );

                    }

                    else {

                        System.out.println(
                                "Dados incorretos!"
                        );

                    }

                    break;

                case 3:

                    System.out.println(
                            "Encerrando..."
                    );

                    break;

                default:

                    System.out.println(
                            "Opção inválida!"
                    );

            }

        } while (opcao != 3);

        sc.close();

    }

}