public class Notificacao {

    public void enviar(
            Cliente cliente,
            String mensagem
    ) {

        System.out.println(
                "\nNOTIFICAÇÃO"
        );

        System.out.println(
                cliente.nome
        );

        System.out.println(
                mensagem
        );

    }

}