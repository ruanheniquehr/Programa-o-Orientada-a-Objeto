public class Usuario {

    String email;
    String senha;

    public Usuario(String email, String senha) {

        this.email = email;
        this.senha = senha;

    }

    public boolean login(String emailDigitado,
                         String senhaDigitada) {

        return email.equals(emailDigitado)
                && senha.equals(senhaDigitada);

    }

}